import { SlotMachine } from "./components/SlotMachine";

export default function App() {
  return <SlotMachine />;
}